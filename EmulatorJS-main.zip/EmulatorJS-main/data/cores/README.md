# EmulatorJS Cores

This package contains the stable cores for EmulatorJS.

Lean more about EmulatorJS at https://emulatorjs.org

Cores are build using this repository:
https://github.com/EmulatorJS/build

## How to install

To install all cores, run the following command:

```bash
npm install @emulatorjs/cores
```
To install a specific core, run the following command:

```bash
npm install @emulatorjs/core-<core-name>
```
